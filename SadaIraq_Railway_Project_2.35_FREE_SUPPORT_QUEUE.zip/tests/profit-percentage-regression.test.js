const fs=require('fs'),path=require('path'),assert=require('assert');
const s=fs.readFileSync(path.join(__dirname,'..','server.js'),'utf8');
const h=fs.readFileSync(path.join(__dirname,'..','index.html'),'utf8');
assert(s.includes('pct<0||pct>1000'), 'API should accept 0-1000%');
assert(!s.includes('pct<100||pct>1000'),'API must not enforce 100% minimum');
assert(!h.includes('pct<100||pct>1000'),'UI must not enforce 100% minimum');
assert(h.includes('يجب أن تكون بين 0 و1000%'),'UI validation message should say 0-1000%');
assert(h.includes('يمكنك اختيار نسبة زيادة من 0% إلى 1000%'),'UI help text should reflect configurable range');
console.log('profit minimum regression tests passed');
