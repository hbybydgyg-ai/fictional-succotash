'use strict';
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const ROOT = require('node:path').resolve(__dirname, '..');
const html = fs.readFileSync(path.join(ROOT, 'index.html'), 'utf8');
const start = html.indexOf('function isServicePinnedForDisplay55(');
const end = html.indexOf('function formatUSD(', start);
assert.ok(start >= 0 && end > start, 'production price-order helpers must exist');
const helperCode = html.slice(start, end);
const sandbox = {
  Number, String, Map, Infinity, Number,
  priceUSD(s) {
    const n = v => { if(v===undefined||v===null||String(v).trim()==='')return null; const x=Number(String(v).replace(/,/g,'')); return Number.isFinite(x)&&x>=0?x:null; };
    const usd=n(s?.sellingUsd); if(usd!==null&&usd>0)return usd;
    const base=n(s?.smmRateUsd??s?.providerRateUsd??s?.smmRate); if(base!==null&&base>0)return base;
    const local=n(s?.price); if(local!==null&&local>0)return local<10?local:local/1250;
    if(usd!==null)return usd;if(local!==null)return local>0&&local<10?local:local/1250;return 0;
  }
};
vm.createContext(sandbox);
vm.runInContext(helperCode + '\nthis.sortServiceRowsByPrice55=sortServiceRowsByPrice55; this.isServicePinnedForDisplay55=isServicePinnedForDisplay55;', sandbox);
const rows = [
  {fbKey:'expensive',name:'غالي',sellingUsd:7},
  {fbKey:'pinned',name:'مثبّت',sellingUsd:99,pinned:true},
  {fbKey:'mid',name:'متوسط',sellingUsd:1},
  {fbKey:'cheap',name:'الأرخص',sellingUsd:0.25},
  {fbKey:'free',name:'مجاني',free:true,sellingUsd:0.5},
  {fbKey:'missing',name:'سعر غير محدد'}
];
const result = sandbox.sortServiceRowsByPrice55(rows, ['expensive','mid','cheap']);
assert.deepEqual(Array.from(result, x=>x.fbKey), ['pinned','free','cheap','mid','expensive','missing']);
assert.equal(sandbox.isServicePinnedForDisplay55(rows[1]), true);
assert.equal(sandbox.isServicePinnedForDisplay55(rows[0]), false);
assert.ok(html.includes("let arr=servicesInCategory(selected)"), 'shared order form source must respect the selected platform/category filter');
assert.ok(html.includes('arr=sortServiceRowsByPrice55(arr,savedOrder)'), 'the All list and every filtered section/platform must use the same price sorter');
console.log('PASS service price sorting: pinned rows first, free/lowest prices first, missing prices last, all/category/platform use shared ordering');
