'use strict';
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const assert=require('node:assert/strict');
const html=fs.readFileSync(path.join(__dirname,'..','index.html'),'utf8');
function extractFunction(source,name){
  const start=source.indexOf('function '+name+'(');
  assert(start>=0,'missing function '+name);
  const open=source.indexOf('{',start);
  assert(open>=0,'missing function body');
  let depth=0,quote='',escaped=false,lineComment=false,blockComment=false;
  for(let i=open;i<source.length;i++){
    const c=source[i],n=source[i+1];
    if(lineComment){if(c==='\\n')lineComment=false;continue;}
    if(blockComment){if(c==='*'&&n==='/'){blockComment=false;i++;}continue;}
    if(quote){if(escaped){escaped=false;continue;}if(c==='\\\\'){escaped=true;continue;}if(c===quote)quote='';continue;}
    if(c==='/'&&n==='/'){lineComment=true;i++;continue;}
    if(c==='/'&&n==='*'){blockComment=true;i++;continue;}
    if(c==='"'||c==="'"||c==='`'){quote=c;continue;}
    if(c==='{')depth++;
    else if(c==='}'&&--depth===0)return source.slice(start,i+1);
  }
  throw new Error('unclosed function '+name);
}
const helper=vm.runInNewContext('('+extractFunction(html,'filterAndSortProviderCatalogRows')+')');
const rows=[
 {service:'200',name:'متوسط',category:'Instagram',rate:0.2,rateValid:true},
 {service:'100',name:'الأرخص',category:'Instagram',rate:0.03,rateValid:true},
 {service:'300',name:'الأغلى',category:'TikTok',rate:3.4,rateValid:true},
 {service:'400',name:'تكلفة غير موثوقة',category:'TikTok',rate:0,rateValid:false},
 {service:'201',name:'متوسط آخر',category:'Instagram',rate:0.2,rateValid:true}
];
const ids=arr=>Array.from(arr,x=>x.service);
assert.deepEqual(ids(helper(rows,'',null,null,'asc')),['100','200','201','300','400'],'ascending sort is cheapest first and stable for equal prices, invalid rates last');
assert.deepEqual(ids(helper(rows,'',null,null,'desc')),['300','200','201','100','400'],'descending sort is most expensive first and stable for equal prices, invalid rates last');
assert.deepEqual(ids(helper(rows,'',null,null,'provider')),['200','100','300','400','201'],'provider mode preserves its original order');
assert.deepEqual(ids(helper(rows,'',0.2,0.2,'asc')),['200','201'],'minimum and maximum filters are inclusive and correctly restrict results');
assert.deepEqual(ids(helper(rows,'',0.03,0.2,'provider')),['200','100','201'],'range filtering keeps matching provider order');
assert.deepEqual(ids(helper(rows,'tiktok',null,null,'asc')),['300','400'],'text query works alongside price sorting');
assert.deepEqual(ids(helper(rows,'',0.4,0.3,'asc')),[],'invalid min/max range returns no candidates');
assert.deepEqual(ids(helper(rows,'',-1,null,'asc')),[],'negative price bounds are rejected');
console.log('PASS free-services provider price sort/filter: cheapest, most expensive, source order, inclusive min/max, invalid rates, stable ties and search');
