const fs=require('fs'),path=require('path'),assert=require('assert'),vm=require('vm');
const html=fs.readFileSync(path.join(__dirname,'..','index.html'),'utf8');
const server=fs.readFileSync(path.join(__dirname,'..','server.js'),'utf8');
const platformAt=html.indexOf('function appForImport(x)');
const platformEnd=html.indexOf('let sourceCacheKey=',platformAt);
assert(platformAt>=0&&platformEnd>platformAt,'canonical importer platform classifier should exist');
const platformBlock=html.slice(platformAt,platformEnd);
assert(platformBlock.indexOf("if(platform.value&&platform.value!=='all')return platform.value")>=0,'administrator selected platform must be authoritative');
assert(platformBlock.indexOf("if(sourcePlatform.value&&sourcePlatform.value!=='all')return sourcePlatform.value")>platformBlock.indexOf("if(platform.value&&platform.value!=='all')return platform.value"),'provider source filter must be lower priority than target platform selection');
assert(html.includes('for(const category of catLabels(x)){const p=platformSignal36(category);if(p)return p;}'),'infer platform from provider category before service title');
// Execute the actual importer classifier with controlled dropdown values.
const classifierStart=html.indexOf('function platformSignal36(value)');
const classifierEnd=html.indexOf('let sourceCacheKey=',classifierStart);
assert(classifierStart>=0&&classifierEnd>classifierStart,'platform classifier block should be extractable');
const classifierCode=html.slice(classifierStart,classifierEnd)+
  ';this.sourcePlatformOf=sourcePlatformOf;this.appForImport=appForImport;';
const aliases=p=>({Instagram:['instagram','insta','انستا','انستجرام','انستغرام'],Tiktok:['tiktok','tik tok','تيك توك','تيكتوك'],Facebook:['facebook','فيسبوك','فيس بوك'],Youtube:['youtube','يوتيوب'],Telegram:['telegram','تلجرام','تيليجرام','تليجرام'],Twitter:['twitter','تويتر','x.com'],Snapchat:['snapchat','سناب'],Whatsapp:['whatsapp','واتساب'],Linkedin:['linkedin','لينكد']})[p]||[];
const sandbox={platform:{value:'Instagram'},sourcePlatform:{value:'Tiktok'},
  aliases,key36:v=>String(v??'').toLowerCase().normalize('NFKC').replace(/[أإآٱ]/g,'ا').replace(/ى/g,'ي').replace(/ة/g,'ه').replace(/[ًٌٍَُِّْـ]/g,'').replace(/[._-]+/g,' '),
  catLabels:x=>[String(x?.category||x?.group||'')].filter(Boolean)};
vm.runInNewContext(classifierCode,sandbox);
assert.equal(sandbox.appForImport({name:'TikTok promo mentions Instagram',category:'TikTok Followers'}),'Instagram','explicit target platform must override the provider-filter selection');
sandbox.platform.value='all';sandbox.sourcePlatform.value='all';
assert.equal(sandbox.appForImport({name:'TikTok Instagram bundle',category:'Instagram Followers'}),'Instagram','in all mode, provider category platform must outrank conflicting service title');
assert.equal(sandbox.appForImport({name:'TikTok followers',category:'TikTok followers'}),'Tiktok','TikTok source-category must remain TikTok');

assert(server.includes("p==='/api/admin/catalog/delete-services'&&(req.method==='GET'||req.method==='POST')"),'admin delete manager endpoint must support list and mutations');
assert(server.includes("action==='reclassify'"),'admin must be able to fix wrongly assigned platform tags');
assert(server.includes("action==='selected'||action==='all'")||server.includes("action!=='selected'&&action!=='all'"),'delete endpoint must support selected rows and all rows in a platform');
assert(server.includes("persistFirebaseCatalogPatch(remotePatch,{verify:true,atomic:true,timeoutMs:60000})"),'deletion must be verified in Firebase before success');
assert(!server.includes("const backupName='catalog-service-delete-'")&&!server.includes("action:'delete-services',platform,providerId"),'targeted service deletion must never write a recovery backup');
assert(server.includes('backupCreated:false')&&server.includes('purgeCatalogServiceSnapshots()'),'targeted delete must report no backup and purge stale service/section snapshots');
assert(html.includes('openPlatformServiceDeleteManager'),'admin UI should expose the platform deletion manager');
assert(html.includes('تصحيح منصة الخدمات المحددة'),'admin UI should let the operator repair wrong platform assignments');
assert(html.includes('حذف حسب المنصة'),'admin services screen should show the new tool');
assert(html.includes('async function deleteAllServices()')&&html.includes('onclick="deleteAllServices()"'),'the original global delete-all handler must remain available');
assert(!html.includes('if(inServiceToolbar&&/حذف الكل|حذف جميع الخدمات/.test(txt))'),'the legacy delete-all button must not be hijacked into the platform manager');
assert(html.includes('حذف جميع خدمات المزود')&&html.includes('حذف خدمات القسم بالكامل'),'manager must support provider-wide and whole-section deletes');
assert(html.includes('تصفية حسب القسم')&&html.includes('جلب/تحديث خدمات المزود'),'manager must expose section filtering and provider update/import workflow');
assert(server.includes("const categoryFilter=normalizeCatalogLabel(String(b.category??''))"),'backend must accept a scoped category filter');
assert(server.includes("providerId===\'all\'")&&server.includes('categoryNamesOf(row).includes(categoryFilter)'),'backend must constrain category and provider-wide deletes');
console.log('service platform mapping and safe deletion regression tests passed');

assert(server.includes("p==='/api/admin/catalog/delete-all'&&(req.method==='GET'||req.method==='POST')"),'global delete button must use a dedicated admin-only endpoint');
assert(server.includes("const patch={services:null,categoryMeta:null,'settings/catalogOrder':emptyOrder,'settings/svcsVersion':version}"),'global deletion must clear live service and section metadata plus catalog ordering in Firebase');
assert(server.includes('reloadLocalCatalogFromFirebase()'),'failed global deletion must recover local mirror from Firebase rather than announce success');
assert(html.includes("fetch('/api/admin/catalog/delete-all'")&&html.includes("localStorage.removeItem('ks_svcs_v1')"),'global delete UI must invalidate browser service cache');
assert(html.includes("window.SECTION_META={}")&&html.includes("window.SADA31_ORDER={categories:[],services:{}}"),'global delete UI must clear in-memory section state');
