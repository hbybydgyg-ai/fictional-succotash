'use strict';
const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const server = fs.readFileSync(path.join(root, 'server.js'), 'utf8');
const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));

const editorStart = html.indexOf('async function openCategoryEditor(existing)');
const editorEnd = html.indexOf('window.openCategoryEditor1605=openCategoryEditor', editorStart);
assert.ok(editorStart >= 0 && editorEnd > editorStart, 'category editor must be exposed for both admin category management views');
const editor = html.slice(editorStart, editorEnd);
assert.ok(editor.includes('window.SADA_ICON_PRESETS_55?.srcs') && editor.includes('imagePreset55:presetSelect.value'), 'category pictures must come from bundled preset library and be saved by preset key');
assert.ok(!/\.type\s*=\s*['"]file['"]/.test(editor) && !editor.includes('FileReader') && !editor.includes('compressImage'), 'category editor must not upload external image files');
assert.ok(editor.includes("[['all','تثبيت في «الكل» وكل المنصات'],['platform','تثبيت داخل منصة واحدة فقط']]") && editor.includes('pinnedPlatform:pinEnable.checked&&pinScope.value===\'platform\'?pinPlatform.value:\'\''), 'category editor must support global and platform-specific pinning');
assert.ok(editor.includes("sectionApi({action:'update',...metadata})") && editor.includes("sectionApi({action:'create',sections:[metadata]})"), 'category editor must use verified server-side persistence for create and edit');
assert.ok(html.includes("createSvc.textContent='➕ إنشاء خدمة'") && html.includes('createSvc.onclick=()=>window.modalAddSvc?.()'), 'service center must provide a direct shortcut to create a service');
assert.ok(html.includes('menu.dataset.sadaBuilt==="1"') && html.includes('opt.dataset.currency=cur.c') && html.includes('menu.dataset.sadaBuilt="1"'), 'sidebar currency options must be built once and then reused');
assert.ok(html.includes('sadairaq-224-sidebar-performance') && html.includes('#sb::before,#sb::after,#adm-panel .adm-sb::before{display:none!important;') && html.includes('transition:transform .18s ease-out!important'), 'sidebar motion should avoid continuously animated backgrounds and heavy mobile blur');
assert.ok(html.includes('pinMatchesActive(resolveMeta(a.name))') && html.includes("const target=normalizePlatform(m.pinnedPlatform);return active!=='all'&&!!target&&target===active;"), 'a platform-scoped pinned category must only be promoted when its platform is selected');
assert.ok(server.includes("imagePreset55=String(b.imagePreset55||'').trim()") && server.includes("platforms:Array.isArray(b.platforms)?cleanPlatforms(b.platforms)"), 'server must validate bundled image preset and persist selected platforms');
assert.equal(pkg.version, '1.6.61');
assert.equal(pkg.buildId, 'SADA-1.6.61-FREE-SUPPORT-QUEUE-20261016');

const start = server.indexOf('function canonicalCatalogOrder(');
const end = server.indexOf('function syncCatalogServiceOrderChanges(', start);
assert.ok(start >= 0 && end > start, 'canonical category ordering helper should be available');
const helper = server.slice(start, end);
const sandbox = {
  JSON, Date,
  normalizeCatalogLabel: v => String(v ?? '').trim().toLowerCase(),
  normalizeCatalogKey: v => String(v ?? '').trim().toLowerCase().replace(/[^a-z0-9_-]+/g, '_') || 'cat',
  readJSON: (_file, fallback) => fallback
};
vm.createContext(sandbox);
vm.runInContext(helper, sandbox);
const ordered = sandbox.canonicalCatalogOrder({ categories: ['Normal', 'Instagram pin', 'Global pin'], services: {} }, {
  a: { name: 'Instagram pin', pinned: true, pinScope: 'platform', pinnedPlatform: 'Instagram' },
  b: { name: 'Global pin', pinned: true, pinScope: 'all' }
});
assert.equal(ordered.categories[0], 'Global pin', 'globally pinned category stays at the top for all platforms');
assert.ok(ordered.categories.indexOf('Instagram pin') > ordered.categories.indexOf('Normal'), 'platform-only pin must not become a global pin');

console.log('PASS category editor: embedded-only images, global/platform pin, service creation shortcut, currency cache, lightweight sidebar, and scoped pin order');
