'use strict';
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const fs = require('node:fs');
const http = require('node:http');
const os = require('node:os');
const path = require('node:path');
const { spawn } = require('node:child_process');

function listen(server) {
  return new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(0, '127.0.0.1', () => { server.removeListener('error', reject); resolve(server.address().port); });
  });
}
function close(server) { return new Promise(resolve => server.close(() => resolve())); }
function wait(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }
async function waitFor(url, proc, output) {
  const deadline = Date.now() + 12000;
  while (Date.now() < deadline) {
    if (proc.exitCode !== null) throw new Error(`server exited early (${proc.exitCode}): ${output()}`);
    try { const r = await fetch(url); if (r.ok) return; } catch (_) {}
    await wait(100);
  }
  throw new Error(`server did not become ready: ${output()}`);
}
function hash(password) {
  const salt = '0123456789abcdef0123456789abcdef';
  return `scrypt$${salt}$${crypto.scryptSync(password, salt, 64).toString('hex')}`;
}
async function captcha(base, origin) {
  const response = await fetch(`${base}/api/auth/captcha`, { headers: { Origin: origin } });
  assert.equal(response.status, 200, 'captcha endpoint should be available');
  const data = await response.json();
  const match = String(data.question || '').match(/(\d+)\s*\+\s*(\d+)/);
  assert.ok(data.captchaId && match, 'captcha response should contain an ID and arithmetic question');
  return { captchaId: data.captchaId, captchaAnswer: String(Number(match[1]) + Number(match[2])) };
}

(async () => {
  const password = 'R0bustPass!2026';
  let appProc, firebase, tempDir, output = '';
  try {
    firebase = http.createServer((req, res) => { res.setHeader('Content-Type', 'application/json'); res.end('null'); });
    const firebasePort = await listen(firebase);
    const probe = http.createServer();
    const appPort = await listen(probe); await close(probe);
    tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'sada-auth-email-'));
    fs.writeFileSync(path.join(tempDir, 'users.json'), JSON.stringify({ users: {
      alice: { username: 'alice', email_address: 'alice@example.com', passwordHash: hash(password), balance: 1200, role: 'user' },
      collision: { username: 'alice@example.com', email: 'collision@example.com', passwordHash: hash('different-password'), balance: 20, role: 'user' }
    } }, null, 2));
    appProc = spawn(process.execPath, [path.join(__dirname, '..', 'server.js')], {
      cwd: path.join(__dirname, '..'),
      env: { ...process.env, NODE_ENV: 'test', PORT: String(appPort), SADA_DATA_DIR: tempDir,
        SESSION_SECRET: 'test-auth-email-secret-key-long-enough-2026',
        FIREBASE_DATABASE_URL: `http://127.0.0.1:${firebasePort}`, FIREBASE_ALLOW_UNAUTHENTICATED: 'true',
        ADMIN_PASSWORD: 'test-only-not-a-production-secret' },
      stdio: ['ignore', 'pipe', 'pipe']
    });
    appProc.stdout.setEncoding('utf8'); appProc.stderr.setEncoding('utf8');
    appProc.stdout.on('data', c => { output += c; }); appProc.stderr.on('data', c => { output += c; });
    const base = `http://127.0.0.1:${appPort}`, origin = base;
    await waitFor(`${base}/api/health`, appProc, () => output);

    const emailCaptcha = await captcha(base, origin);
    const emailLogin = await fetch(`${base}/api/auth`, { method: 'POST', headers: { 'Content-Type': 'application/json', Origin: origin },
      body: JSON.stringify({ username: 'alice@example.com', password, ...emailCaptcha }) });
    const emailData = await emailLogin.json();
    assert.equal(emailLogin.status, 200, `email login should succeed: ${JSON.stringify(emailData)}`);
    assert.equal(emailData.username, 'alice', 'email should resolve to the record whose email field matches, not a similarly named login alias');
    assert.equal(emailData.role, 'user');

    const usernameCaptcha = await captcha(base, origin);
    const usernameLogin = await fetch(`${base}/api/auth`, { method: 'POST', headers: { 'Content-Type': 'application/json', Origin: origin },
      body: JSON.stringify({ username: 'alice', password, ...usernameCaptcha }) });
    const usernameData = await usernameLogin.json();
    assert.equal(usernameLogin.status, 200, `username login should continue to work: ${JSON.stringify(usernameData)}`);
    assert.equal(usernameData.username, 'alice');

    const unauthImage = await fetch(`${base}/api/admin/custom-shop/image`, { method: 'POST', headers: { 'Content-Type': 'application/json', Origin: origin }, body: '{}' });
    assert.equal(unauthImage.status, 403, 'image upload must reject unauthenticated requests');

    const adminPayload = Buffer.from(JSON.stringify({ role: 'admin', username: 'test-owner', iat: Date.now() }), 'utf8').toString('base64url');
    const adminSignature = crypto.createHmac('sha256', 'test-auth-email-secret-key-long-enough-2026').update(adminPayload).digest('base64url');
    const adminToken = `${adminPayload}.${adminSignature}`;
    const imageUpload = await fetch(`${base}/api/admin/custom-shop/image`, { method: 'POST', headers: { 'Content-Type': 'application/json', Origin: origin, 'x-sada-session': adminToken },
      body: JSON.stringify({ imageData: 'data:image/png;base64,iVBORw0KGgo=' }) });
    const imageData = await imageUpload.json();
    assert.equal(imageUpload.status, 200, `admin image upload should succeed: ${JSON.stringify(imageData)}`);
    assert.match(imageData.imageUrl, /^\/media\/custom-shop\/custom-[a-f0-9]+\.png$/);
    const servedImage = await fetch(`${base}${imageData.imageUrl}`);
    assert.equal(servedImage.status, 200, 'uploaded image should be served from the dedicated media path');
    assert.equal(servedImage.headers.get('content-type'), 'image/png');

    console.log('PASS auth regression: email-first legacy email lookup, username login, admin-only image upload, and media serving');
  } catch (e) {
    console.error(e);
    if (output) console.error('server output:\n' + output.slice(-6000));
    process.exitCode = 1;
  } finally {
    if (appProc && appProc.exitCode === null) { appProc.kill('SIGTERM'); await wait(150); if (appProc.exitCode === null) appProc.kill('SIGKILL'); }
    if (firebase) await close(firebase).catch(() => {});
    if (tempDir) fs.rmSync(tempDir, { recursive: true, force: true });
  }
})();
