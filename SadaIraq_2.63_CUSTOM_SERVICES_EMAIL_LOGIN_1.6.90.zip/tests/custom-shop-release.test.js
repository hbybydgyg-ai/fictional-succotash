'use strict';
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const fs = require('node:fs');
const http = require('node:http');
const os = require('node:os');
const path = require('node:path');
const { spawn } = require('node:child_process');

function listen(server) { return new Promise((resolve, reject) => { server.once('error', reject); server.listen(0, '127.0.0.1', () => { server.removeListener('error', reject); resolve(server.address().port); }); }); }
function close(server) { return new Promise(resolve => server.close(() => resolve())); }
function wait(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }
async function waitFor(url, proc, getOutput) { const until = Date.now() + 12000; while (Date.now() < until) { if (proc.exitCode !== null) throw new Error(`server exited early: ${getOutput()}`); try { const r = await fetch(url); if (r.ok) return; } catch (_) {} await wait(100); } throw new Error(`server did not start: ${getOutput()}`); }
function signedSession(secret, username, role) { const payload = Buffer.from(JSON.stringify({ role, username, iat: Date.now() }), 'utf8').toString('base64url'); const sig = crypto.createHmac('sha256', secret).update(payload).digest('base64url'); return `${payload}.${sig}`; }
function pathParts(pathname) { return decodeURIComponent(pathname).split('/').filter(Boolean).map((x, i, arr) => i === arr.length - 1 ? x.replace(/\.json$/i, '') : x).filter(Boolean); }
function getAt(root, parts) { let value = root; for (const key of parts) { if (!value || typeof value !== 'object' || !Object.prototype.hasOwnProperty.call(value, key)) return null; value = value[key]; } return value === undefined ? null : value; }
function putAt(root, parts, value) { if (!parts.length) return value; let node = root; for (const key of parts.slice(0, -1)) { if (!node[key] || typeof node[key] !== 'object' || Array.isArray(node[key])) node[key] = {}; node = node[key]; } if (value === null) delete node[parts.at(-1)]; else node[parts.at(-1)] = value; return root; }
async function body(req) { let raw = ''; for await (const chunk of req) raw += chunk; return raw ? JSON.parse(raw) : null; }

(async () => {
  const secret = 'custom-shop-test-secret-key-long-enough-2026';
  let store = {};
  let appProc, firebase, tempDir, output = '';
  try {
    firebase = http.createServer(async (req, res) => {
      res.setHeader('Content-Type', 'application/json');
      try {
        const u = new URL(req.url, 'http://127.0.0.1'), parts = pathParts(u.pathname);
        if (req.method === 'GET') { const value = getAt(store, parts); res.end(JSON.stringify(value)); return; }
        if (req.method === 'PUT') { const value = await body(req); store = putAt(store, parts, value); res.end(JSON.stringify(value)); return; }
        if (req.method === 'PATCH') { const patch = await body(req) || {}; const current = getAt(store, parts) || {}; for (const [k, v] of Object.entries(patch)) { const sub = k.split('/').filter(Boolean); store = putAt(store, [...parts, ...sub], v); } res.end(JSON.stringify(getAt(store, parts))); return; }
        if (req.method === 'DELETE') { store = putAt(store, parts, null); res.end('null'); return; }
        res.statusCode = 405; res.end(JSON.stringify({ error: 'method not allowed' }));
      } catch (e) { res.statusCode = 400; res.end(JSON.stringify({ error: String(e.message || e) })); }
    });
    const firebasePort = await listen(firebase);
    const probe = http.createServer(); const appPort = await listen(probe); await close(probe);
    tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'sada-custom-shop-'));
    appProc = spawn(process.execPath, [path.join(__dirname, '..', 'server.js')], { cwd: path.join(__dirname, '..'), env: { ...process.env, NODE_ENV: 'test', PORT: String(appPort), SADA_DATA_DIR: tempDir, SESSION_SECRET: secret, FIREBASE_DATABASE_URL: `http://127.0.0.1:${firebasePort}`, FIREBASE_ALLOW_UNAUTHENTICATED: 'true', ADMIN_PASSWORD: 'test-only-not-a-production-secret' }, stdio: ['ignore', 'pipe', 'pipe'] });
    appProc.stdout.setEncoding('utf8'); appProc.stderr.setEncoding('utf8'); appProc.stdout.on('data', c => { output += c; }); appProc.stderr.on('data', c => { output += c; });
    const base = `http://127.0.0.1:${appPort}`, adminToken = signedSession(secret, 'release-test-admin', 'admin');
    await waitFor(`${base}/api/health`, appProc, () => output);
    const denied = await fetch(`${base}/api/admin/custom-shop`, { headers: { 'x-sada-session': signedSession(secret, 'regular-user', 'user') } });
    assert.equal(denied.status, 403, 'normal users must not access the admin custom-shop catalog');

    const categoryResponse = await fetch(`${base}/api/admin/custom-shop`, { method: 'POST', headers: { 'Content-Type': 'application/json', 'x-sada-session': adminToken }, body: JSON.stringify({ action: 'category_save', key: 'telegram_subs', name: 'اشتراكات تيليجرام', description: 'خدمات يدوية مستقلة عن المزود', platforms: ['Telegram'], imageUrl: '' }) });
    const categoryData = await categoryResponse.json();
    assert.equal(categoryResponse.status, 200, `admin should be able to create a category: ${JSON.stringify(categoryData)}`);
    assert.equal(categoryData.category.name, 'اشتراكات تيليجرام');

    const serviceResponse = await fetch(`${base}/api/admin/custom-shop`, { method: 'POST', headers: { 'Content-Type': 'application/json', 'x-sada-session': adminToken }, body: JSON.stringify({ action: 'service_save', key: 'channel_subscription', categoryKey: 'telegram_subs', name: 'اشتراك قناة تجريبي', description: 'ينفذ يدوياً عبر واتساب', platforms: ['Telegram'], priceIQD: 2500, minQuantity: 1, maxQuantity: 1, inputLabel: 'رابط القناة', inputPlaceholder: 'https://t.me/channel', inputType: 'url', requiresInput: true, imageUrl: '', enabled: true }) });
    const serviceData = await serviceResponse.json();
    assert.equal(serviceResponse.status, 200, `admin should be able to create a service: ${JSON.stringify(serviceData)}`);
    assert.equal(serviceData.service.serviceKind, 'custom_shop');
    assert.equal(serviceData.service.priceIQD, 2500);

    const catalogResponse = await fetch(`${base}/api/custom-shop`);
    const catalog = await catalogResponse.json();
    assert.equal(catalogResponse.status, 200, `public catalog should load: ${JSON.stringify(catalog)}`);
    assert.ok(catalog.categories.some(x => x.key === 'telegram_subs'), 'saved category should persist and appear in the public catalog');
    assert.ok(catalog.services.some(x => x.key === 'channel_subscription' && x.categoryKey === 'telegram_subs'), 'saved service should persist and appear under its selected category');
    assert.ok(store.customShop?.categories?.telegram_subs && store.customShop?.services?.channel_subscription, 'category and service should be saved in Firebase paths under customShop');
    console.log('PASS custom-shop regression: admin-only management, category/service persistence, and public catalog visibility');
  } catch (e) { console.error(e); if (output) console.error('server output:\n' + output.slice(-7000)); process.exitCode = 1; }
  finally { if (appProc && appProc.exitCode === null) { appProc.kill('SIGTERM'); await wait(150); if (appProc.exitCode === null) appProc.kill('SIGKILL'); } if (firebase) await close(firebase).catch(() => {}); if (tempDir) fs.rmSync(tempDir, { recursive: true, force: true }); }
})();
