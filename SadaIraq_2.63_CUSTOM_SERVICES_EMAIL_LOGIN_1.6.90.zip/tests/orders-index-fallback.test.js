'use strict';
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const fs = require('node:fs');
const http = require('node:http');
const os = require('node:os');
const path = require('node:path');
const { spawn } = require('node:child_process');

function listen(server) {
  return new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(0, '127.0.0.1', () => {
      server.removeListener('error', reject);
      resolve(server.address().port);
    });
  });
}
function close(server) {
  return new Promise(resolve => server.close(() => resolve()));
}
function wait(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }
async function waitFor(url, proc, output) {
  const deadline = Date.now() + 10000;
  while (Date.now() < deadline) {
    if (proc.exitCode !== null) throw new Error(`server exited early (${proc.exitCode}): ${output()}`);
    try { const r = await fetch(url); if (r.ok) return; } catch (_) {}
    await wait(100);
  }
  throw new Error(`server did not become ready: ${output()}`);
}

(async () => {
  const targetUser = 'ahmed9900';
  const secret = 'test-orders-index-fallback-secret-0123456789';
  const rules = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'database.rules.json'), 'utf8'));
  assert.ok(rules.rules.orders['.indexOn'].includes('user'), 'release rules must include the user index for orders');
  const records = {
    '-firebase-key-3003': { id: '3003', publicOrderNo: '3003', user: targetUser, serviceName: 'اختبار طلب محفوظ', status: 'pending', createdAt: '2026-10-20T12:00:00.000Z', total: 100 },
    '-firebase-key-3004': { id: '3004', publicOrderNo: '3004', user: 'another-user', serviceName: 'طلب مستخدم آخر', status: 'pending', createdAt: '2026-10-20T12:01:00.000Z', total: 100 }
  };
  let indexedUserQueries = 0;
  let rootOrderReads = 0;
  const mockFirebase = http.createServer((req, res) => {
    const u = new URL(req.url, 'http://127.0.0.1');
    res.setHeader('Content-Type', 'application/json');
    if (u.pathname === '/orders.json' && u.searchParams.get('orderBy') === '"user"') {
      indexedUserQueries++;
      res.statusCode = 400;
      res.end(JSON.stringify({ error: 'Index not defined, add "indexOn": "user", for path "/orders"' }));
      return;
    }
    if (u.pathname === '/orders.json' && !u.search) {
      rootOrderReads++;
      res.end(JSON.stringify(records));
      return;
    }
    // Other warm-up/probe paths are intentionally isolated from real Firebase.
    if (u.pathname === '/orders.json') { res.end(JSON.stringify({})); return; }
    res.end('null');
  });

  let appProc;
  let appPort;
  let tempDir;
  let output = '';
  try {
    const firebasePort = await listen(mockFirebase);
    const portProbe = http.createServer();
    appPort = await listen(portProbe);
    await close(portProbe);
    tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'sada-orders-index-fallback-'));
    fs.writeFileSync(path.join(tempDir, 'orders.json'), '[]\n');
    const sessionPayload = Buffer.from(JSON.stringify({ role: 'user', username: targetUser, iat: Date.now() }), 'utf8').toString('base64url');
    const signature = crypto.createHmac('sha256', secret).update(sessionPayload).digest('base64url');
    const sessionToken = sessionPayload + '.' + signature;
    appProc = spawn(process.execPath, [path.join(__dirname, '..', 'server.js')], {
      cwd: path.join(__dirname, '..'),
      env: {
        ...process.env,
        NODE_ENV: 'test',
        PORT: String(appPort),
        SADA_DATA_DIR: tempDir,
        SESSION_SECRET: secret,
        FIREBASE_DATABASE_URL: `http://127.0.0.1:${firebasePort}`,
        FIREBASE_ALLOW_UNAUTHENTICATED: 'true',
        ADMIN_PASSWORD: 'test-only-not-a-production-secret'
      },
      stdio: ['ignore', 'pipe', 'pipe']
    });
    appProc.stdout.setEncoding('utf8'); appProc.stderr.setEncoding('utf8');
    appProc.stdout.on('data', chunk => { output += chunk; });
    appProc.stderr.on('data', chunk => { output += chunk; });
    const base = `http://127.0.0.1:${appPort}`;
    await waitFor(`${base}/api/health`, appProc, () => output);
    const healthResponse = await fetch(`${base}/api/health`);
    const health = await healthResponse.json();
    assert.equal(health.version, '1.6.90');
    assert.equal(health.deploymentConsistent, true, 'server, UI and release metadata must match');
    const response = await fetch(`${base}/api/user/orders`, { headers: { 'x-sada-session': sessionToken } });
    const body = await response.json();
    assert.equal(response.status, 200, `expected API 200; got ${response.status}: ${JSON.stringify(body)}`);
    assert.equal(body.ok, true);
    assert.equal(body.source, 'hosting-file+firebase-index-fallback');
    assert.equal(body.orders.length, 1, 'only the authenticated user\'s order should be returned');
    assert.equal(String(body.orders[0].id), '3003');
    assert.equal(body.orders[0].user, targetUser);
    assert.equal(body.warning, undefined, 'a successful fallback must not display a Firebase error to the user');
    assert.ok(indexedUserQueries >= 1, 'the test must reproduce the missing-index query failure');
    assert.ok(rootOrderReads >= 1, 'the server must retry using a read-only fallback');
    console.log('PASS orders index fallback: missing-index 400 recovered, user order restored, other user order excluded');
  } finally {
    if (appProc && appProc.exitCode === null) { appProc.kill('SIGTERM'); await Promise.race([new Promise(resolve => appProc.once('exit', resolve)), wait(2000)]); if (appProc.exitCode === null) appProc.kill('SIGKILL'); }
    await close(mockFirebase).catch(() => {});
    if (tempDir) fs.rmSync(tempDir, { recursive: true, force: true });
  }
})().catch(error => { console.error(error.stack || error); process.exitCode = 1; });
