'use strict';
const fs = require('fs');
const path = require('path');
const assert = require('assert');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const server = fs.readFileSync(path.join(root, 'server.js'), 'utf8');

const earnStart = html.indexOf('function tasksForPlatform()');
const earnEnd = html.indexOf('\nfunction taskCard(', earnStart);
assert(earnStart >= 0 && earnEnd > earnStart, 'platform task filter must exist');
const filter = html.slice(earnStart, earnEnd);
assert(filter.includes("new Set(['pending_review','reviewing','approved'])"), 'tasks with proof under review or accepted are locked');
assert(filter.includes("const completedTasks=userData?.wallet?.completedTasks||{}"), 'the wallet completion map should be consumed');
assert(filter.includes("(isCamp?'campaign_':'task_')+String(t.id||'')"), 'task type is namespaced when looking up completion');
assert(filter.includes('if(completedTasks[completedKey])return false'), 'approved task is removed after its review row is deleted');
assert(filter.includes('Number(t.completedQuantity||0)+Number(t.reservedQuantity||0)') || filter.includes('Number(t.quantity||0)-Number(t.completedQuantity||0)-Number(t.reservedQuantity||0)'), 'campaign task with no quantity left is hidden');

const renderStart = html.indexOf('function renderEarn()');
const renderEnd = html.indexOf('function startTask(', renderStart);
assert(renderStart >= 0 && renderEnd > renderStart, 'earn render function must exist');
const render = html.slice(renderStart, renderEnd);
assert(render.includes("b.onclick=()=>{currentPlatform=b.dataset.fsPlatform;earnMode='tasks';renderEarn()}"), 'selecting a platform takes the user straight to its tasks');
assert(render.includes("if(earnMode==='hub'){earnMode='tasks';renderEarn();return;}"), 'legacy intermediate hub safely redirects to direct tasks');
assert(!render.includes('fs-platform-my-tasks'), 'no intermediate My Tasks card remains in the earn flow');
assert(render.includes('fs-platform-choose'), 'platform cards still clearly present the choose/open task affordance');

const walletStart = server.indexOf('async function freeSupportAward(');
const walletEnd = server.indexOf('\nasync function freeSupportRefund(', walletStart);
assert(walletStart >= 0 && walletEnd > walletStart, 'server point-award function must exist');
const award = server.slice(walletStart, walletEnd);
assert(award.includes('const completedTasks={...freeSupportObject(wallet.completedTasks)}'), 'award handler copies persistent completion map');
assert(award.includes("request.campaignId?'campaign_'+String(request.campaignId):request.taskId?'task_'+String(request.taskId):''"), 'award stores task/campaign completion using the correct namespace');
assert(award.includes('wallet.completedTasks=completedTasks'), 'completed tasks are persisted atomically with wallet update');
const getResponse = server.slice(server.indexOf('async function freeSupportRoute'), server.indexOf("if(p==='/api/free-support'||p==='/api/free-support/review'||p==='/api/admin/free-support')") + 100000);
assert(getResponse.includes('completedTasks:freeSupportObject(wallet.completedTasks)'), 'wallet GET returns completed task IDs to the client');
console.log('PASS direct platform flow: no intermediate cards, pending proof lock and persistent completed-task exclusion');
