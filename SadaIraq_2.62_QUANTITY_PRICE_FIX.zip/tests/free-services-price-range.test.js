'use strict';
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const root = path.join(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const server = fs.readFileSync(path.join(root, 'server.js'), 'utf8');
const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
const cfg = JSON.parse(fs.readFileSync(path.join(root, 'config.json'), 'utf8'));
const build = 'SADA-1.6.86-FLAT-ORDER-PRICE-20261020';
assert.equal(cfg.version, '2.60', 'visible release version must match');
assert.equal(pkg.version, '1.6.86', 'technical release version must match');
assert.equal(pkg.buildId, build, 'package build ID must match');
assert.equal(cfg.buildId, build, 'config build ID must match');
assert(html.includes("const shown='2.60'"), 'sidebar visible version must be 2.40');
assert(html.includes('أقل تكلفة للمزود / 1000 USD'), 'bulk free-services picker must have minimum provider cost field');
assert(html.includes('أعلى تكلفة للمزود / 1000 USD'), 'bulk free-services picker must have maximum provider cost field');
assert(html.includes("['asc','الأقل سعراً أولاً']") && html.includes("['desc','الأعلى سعراً أولاً']"), 'picker must sort both cheapest-first and most-expensive-first');
assert(html.includes('ترتيب المزود الأصلي'), 'picker must retain provider-native order as an option');
assert(html.includes('function filterAndSortProviderCatalogRows(rows, query, minRate, maxRate, sortMode)'), 'price filter and sorting should use one reusable function');
assert(html.includes('hasMin&&hasMax&&min>max'), 'invalid inverted price range must be rejected before filtering');
assert(html.includes('rate<min') && html.includes('rate>max'), 'min/max limits must filter on validated provider rates');
assert(html.includes("pickerMinRate.addEventListener('input',()=>renderProviderPicker(true));pickerMaxRate.addEventListener('input',()=>renderProviderPicker(true));pickerPriceSort.addEventListener('change',()=>renderProviderPicker(true));"), 'filters and sort must rerender the visible provider service list');
assert(html.includes('تغيير التصفية لا يلغي الخدمات التي حددتها سابقاً'), 'selection persistence must be communicated when filters change');
assert(html.includes("action:'save-bulk'"), 'filtered selections must still use the existing bulk-save action');
assert(server.includes("if(action==='save-bulk')"), 'server bulk free-service path must remain enabled');
assert(server.includes('ADMIN_FREE_SERVICES_GLOBAL_DAILY_LIMIT=2'), 'shared quota remains fixed at two per account in 24 hours');

const helperStart = html.indexOf('function filterAndSortProviderCatalogRows(');
const helperEnd = html.indexOf('function renderProviderPicker(', helperStart);
assert(helperStart >= 0 && helperEnd > helperStart, 'price filter helper must be extractable for behavioral testing');
const helperSource = html.slice(helperStart, helperEnd).trim();
const filterRows = vm.runInNewContext('(' + helperSource + ')');
const sample = [
  { service: 'high', name: 'Highest', rate: 0.08, rateValid: true },
  { service: 'mid', name: 'Middle', rate: 0.025, rateValid: true },
  { service: 'low', name: 'Lowest', rate: 0.005, rateValid: true },
  { service: 'unknown', name: 'Unknown cost', rate: null, rateValid: false }
];
const ids = rows => Array.from(rows, row => row.service);
assert.deepEqual(ids(filterRows(sample, '', null, null, 'asc')), ['low', 'mid', 'high', 'unknown'], 'ascending sort must put cheapest valid rate first and unknown rates last');
assert.deepEqual(ids(filterRows(sample, '', null, null, 'desc')), ['high', 'mid', 'low', 'unknown'], 'descending sort must put most expensive valid rate first and unknown rates last');
assert.deepEqual(ids(filterRows(sample, '', 0.01, 0.03, 'asc')), ['mid'], 'range filter must return only services within inclusive min/max provider costs');
assert.deepEqual(ids(filterRows(sample, '', 0.04, 0.02, 'asc')), [], 'inverted price bounds must return no services');
assert.deepEqual(ids(filterRows(sample, 'high', null, null, 'provider')), ['high'], 'text search must work with provider-native order');
console.log('PASS free-services price filters: min/max cost, asc/desc sort, invalid-range handling, unknown prices, text search, retained selection, and unchanged shared quota');
