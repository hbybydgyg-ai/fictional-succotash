const fs=require('fs');
const path=require('path');
const root=path.resolve(__dirname,'..');
const server=fs.readFileSync(path.join(root,'server.js'),'utf8');
const pkg=JSON.parse(fs.readFileSync(path.join(root,'package.json'),'utf8'));
const cfg=JSON.parse(fs.readFileSync(path.join(root,'config.json'),'utf8'));
const build=fs.readFileSync(path.join(root,'BUILD_ID.txt'),'utf8').trim();
assertNoOrdersCreatedAtIndex(server);
function assertNoOrdersCreatedAtIndex(source){
  const bad=/firebaseGetQueryJson\(['"]orders['"]\s*,\s*\{\s*orderBy\s*:\s*['"]\\?"createdAt\\?"['"]/;
  if(bad.test(source)) throw new Error('orders listing/monitor must not require createdAt index');
  if(!source.includes("firebaseGetQueryJson('orders',{orderBy:'\\\"$key\\\"',limitToLast:500}")) {
    throw new Error('bounded orders query must use Firebase built-in $key ordering');
  }
}
if(pkg.version!=='1.6.84'||cfg.version!=='2.58'||pkg.buildId!==build||cfg.buildId!==build) throw new Error('release version/build identity mismatch');
console.log('PASS Firebase orders use built-in $key ordering without createdAt index');
