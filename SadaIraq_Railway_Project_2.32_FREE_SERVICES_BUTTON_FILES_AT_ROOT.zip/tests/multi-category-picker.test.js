'use strict';
const fs = require('node:fs');
const assert = require('node:assert/strict');
const ROOT = require('node:path').resolve(__dirname, '..');
const html = fs.readFileSync(ROOT + '/index.html', 'utf8');
const pkg = JSON.parse(fs.readFileSync(ROOT + '/package.json', 'utf8'));
const expectedBuild = 'SADA-1.6.58-FREE-SERVICES-VISIBLE-ADMIN-CARD-20261015';
const checks = [
  ['custom touch picker replaces the native multiple select as the visible control', html.includes("providerCat.multiple=true") && html.includes("providerCat.style.display='none'") && html.includes("field('أقسام المزود المصدر — اضغط واختر عدة أقسام بعلامة الصح',providerCatPicker)")],
  ['source section dropdown opens and exposes its expanded state', html.includes("providerCatTrigger.addEventListener('click'") && html.includes('providerCatPanel.hidden=!opening') && html.includes("setAttribute('aria-expanded',String(opening))")],
  ['each category has a checkbox and an explicit check mark for multi-selection', html.includes("cb.className='sada36-cat-choice-check'") && html.includes("opt.selected=cb.checked") && html.includes("tick.textContent='✓'")],
  ['selection is persistent while choosing other categories and shows all selected names', html.includes('function selectedProviderCats36()') && html.includes('selected.join(\'، \')') && html.includes('providerCatSelectedCount.textContent')],
  ['multi-category import keeps each selected source category paired with its own services and site category', html.includes('selectedCats.map(src=>({source:src,target:canonicalName(src),rows:chosen.filter') && html.includes("groups:[entry.target],categories:[entry.target],category:entry.target")],
  ['new categories are not committed empty before service import succeeds', html.includes('Do not create empty category records before import') && html.includes("'/api/admin/services/import'") && !html.includes('const namesToCreate=entries.filter(e=>!existingNames.some')],
  ['service names display fully, wrap to multiple lines, and use larger readable text', html.includes('.sada36-row-main b{display:block;color:var(--t0);font-size:16px;font-weight:850;line-height:1.75;white-space:normal;overflow:visible;text-overflow:clip;overflow-wrap:anywhere;word-break:normal}')],
  ['category names use large Arabic text and wrap rather than truncate', html.includes('.sada36-cat-choice-name{display:block;color:#f0efff;font-size:16px;font-weight:800;line-height:1.8;white-space:normal;overflow-wrap:anywhere;word-break:normal}')],
  ['the release build marker is synchronized between HTML and package metadata', html.includes('name="sada-build-id" content="' + expectedBuild + '"') && pkg.buildId === expectedBuild]
];
let failures = 0;
for (const [name, ok] of checks) { console.log((ok ? 'PASS ' : 'FAIL ') + name); if (!ok) failures++; }
if (failures) process.exit(1);
console.log('PASS multi-category picker smoke: ' + checks.length + ' focused regression checks');
