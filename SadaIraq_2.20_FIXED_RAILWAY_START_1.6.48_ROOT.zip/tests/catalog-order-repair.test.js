'use strict';
const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const source = fs.readFileSync(require('node:path').join(__dirname, '..', 'server.js'), 'utf8');
const start = source.indexOf('function catalogObject(value)');
const end = source.indexOf('async function reloadLocalCatalogFromFirebase()', start);
assert.ok(start >= 0 && end > start, 'Firebase catalog helper block should exist');
const helperCode = source.slice(start, end);
const db = {
  settings: {catalogOrder: {categories:['القسم القديم'], services:{old:['s1']}}, svcsVersion: 'old'},
  categoryMeta: {old:{name:'القسم القديم'}},
  services: {s1:{name:'خدمة قديمة',groups:['القسم القديم'],category:'القسم القديم'}}
};
function getPath(p) { return String(p||'').split('/').filter(Boolean).reduce((v,k)=>v&&typeof v==='object'?v[k]:null, db) ?? null; }
function setPath(p,v) { const parts=String(p||'').split('/').filter(Boolean); let cur=db; for(const k of parts.slice(0,-1)){if(!cur[k]||typeof cur[k]!=='object')cur[k]={};cur=cur[k];} if(parts.length)cur[parts.at(-1)]=v; }
const sandbox = {
  console,
  setTimeout,
  Promise,
  JSON,
  Object,
  Array,
  String,
  Number,
  Math,
  Buffer,
  normalizeCatalogLabel: v => String(v??'').trim().toLowerCase(),
  catalogRowGroups: row => [...new Set([row?.category,...(Array.isArray(row?.groups)?row.groups:[])].map(x=>String(x??'').trim()).filter(Boolean))],
  canonicalCatalogOrder: order => order,
  readJSON: file => file==='category_meta.json'?{}:file==='services.json'?{}:{},
  async firebaseGetJson(path) { return JSON.parse(JSON.stringify(getPath(path))); },
  async firebaseWriteJson(path,value) { setPath(path, JSON.parse(JSON.stringify(value))); return value; },
  async firebasePatchJson(_path, patch) {
    // Simulate the observed failure mode: root multi-path PATCH returns success, but catalogOrder
    // is not reflected by the following GET. The dedicated repair should write it and verify again.
    for (const [path,value] of Object.entries(patch)) if (path!=='settings/catalogOrder') setPath(path,value);
    return null;
  },
  async firebaseDeleteJson(path) { const parts=String(path).split('/');let p=db;for(const k of parts.slice(0,-1))p=p?.[k];if(p)delete p[parts.at(-1)];return null; }
};
vm.runInNewContext(helperCode+'\n;globalThis.__test={catalogOrderValuesEqual,persistFirebaseCatalogPatch};',sandbox,{timeout:5000});
(async()=>{
  const {catalogOrderValuesEqual,persistFirebaseCatalogPatch}=sandbox.__test;
  assert.equal(catalogOrderValuesEqual({categories:{'0':'A'},services:{x:{'0':'id1'}}},{categories:['A'],services:{x:['id1']}}),true,'numeric-key Firebase arrays should compare semantically');
  const wanted={categories:['القسم الجديد'],services:{new:['s2']}};
  const out=await persistFirebaseCatalogPatch({'settings/catalogOrder':wanted,'settings/svcsVersion':'new'},{verify:true,atomic:true});
  assert.equal(out.count,2);
  const finalOrder=db.settings.catalogOrder;
  assert.ok(finalOrder.categories.includes('القسم الجديد'),'the new section should be saved');
  assert.ok(finalOrder.categories.includes('القسم القديم'),'existing remote sections must be preserved');
  assert.deepEqual(Array.from(finalOrder.services.new),['s2']);
  assert.deepEqual(Array.from(finalOrder.services.old),['s1']);
  assert.equal(db.settings.svcsVersion,'new');
  console.log('PASS catalog order repair: mismatched read-back triggers a targeted write, verifies it, preserves existing sections and adds selected sections');
})().catch(error=>{console.error('FAIL catalog order repair:',error.stack||error);process.exit(1)});
