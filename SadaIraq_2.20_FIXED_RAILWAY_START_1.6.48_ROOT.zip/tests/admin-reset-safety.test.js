
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const root = path.resolve(__dirname, '..');
const server = fs.readFileSync(path.join(root, 'server.js'), 'utf8');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');

function lastResetBlock(source) {
  const markers = [...source.matchAll(/window\.clearAllAppData\s*=\s*async function\s*\(\)/g)];
  assert.ok(markers.length >= 2, 'both legacy assignments should remain identifiable for regression coverage');
  const start = markers.at(-1).index;
  const end = source.indexOf('\n  /* ----- support URL + settings sync on startup ----- */', start);
  assert.ok(end > start, 'the final cleanup assignment should have a clear ending');
  return source.slice(start, end);
}
const activeReset = lastResetBlock(html);
assert.ok(activeReset.includes("scope:'customers-and-orders'"), 'the active UI must request the restricted cleanup scope');
assert.ok(activeReset.includes("confirmation:'CLEAN_CUSTOMERS_AND_ORDERS'"), 'the active UI must send the explicit confirmation token');
assert.ok(!/DB\.ref\(['"](?:users|orders|services|categoryMeta|providerServices|payments)['"]\)\.remove\(/.test(activeReset), 'the browser must not delete Firebase branches directly');
assert.ok(activeReset.includes("result.ok!==true"), 'the UI must reject unconfirmed server success');

const routeStart = server.indexOf("if(p==='/api/admin/reset' && req.method==='POST')");
const routeEnd = server.indexOf("if(p==='/api/admin/user-balance'", routeStart);
assert.ok(routeStart >= 0 && routeEnd > routeStart, 'the scoped reset route should exist');
const route = server.slice(routeStart, routeEnd);
assert.ok(route.includes("requestBody.scope||'')!=='customers-and-orders'"), 'the server must reject an unscoped reset');
assert.ok(route.includes("requestBody.confirmation||'')!=='CLEAN_CUSTOMERS_AND_ORDERS'"), 'the server must require a confirmation token');
assert.ok(route.includes("const patch={'orders':null,'settings/orderCounter':2999}"), 'the reset must clear orders and set the next order floor to 3000');
assert.ok(route.includes("persistFirebaseCatalogPatch(patch,{verify:true,atomic:true"), 'Firebase write must be verified before local mirrors are changed');
assert.ok(route.includes("writeJSON('orders.json',[])"), 'the local order mirror should clear only after Firebase verification');
assert.ok(!/patch\[['"](?:services|categoryMeta|providerServices|settings\/catalogOrder|config\/smmProviders)\//.test(route), 'the reset must never patch catalog or provider settings');
assert.ok(!route.includes("writeJSON('payments.json'"), 'payments are outside this cleanup scope');
assert.ok(route.includes("return json(res,502,{ok:false"), 'Firebase failure must return an error instead of success');

assert.ok(html.includes('const catalogPriceUsd32=s=>') || html.includes('function catalogPriceUsd32(s)'), 'admin catalog price fallback helper should exist');
assert.ok(html.includes('if(usd!==null&&usd>0)return usd;'), 'a stale zero selling price must not suppress fallback values');
assert.ok(html.includes('s?.baseProviderRateUsd??s?.smmRate'), 'base provider rate must be considered by price fallback');
assert.ok(html.includes('const priceIQD12=s=>Number((priceUSD12(s)*RATE12).toFixed(4));'), 'order IQD calculation must use the normalized USD price');
assert.ok(server.includes('function catalogSellingRate(row={})'), 'server-side shared selling price resolver must exist');
assert.ok(server.includes('const serviceRate=catalogSellingRate(svc);'), 'website orders must use normalized selling price');
assert.ok(server.includes('const sellingUsd=catalogSellingRate(raw);'), 'public API catalog must use normalized selling price');

console.log('PASS admin reset safety: scoped deletion, protected catalog/payment data, verified Firebase write, no false success and robust price fallback');
