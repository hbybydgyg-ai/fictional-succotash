const fs=require('fs');const assert=require('assert');const h=fs.readFileSync('index.html','utf8');
assert(h.includes("button('إدارة الخدمات المجانية'"),'visible service workspace must expose a dedicated free-services button');
assert(h.includes("window.SADA_ADMIN_FREE_SERVICES_21?.open==='function'"),'button must call the existing free-service manager');
assert(h.includes('sada-free-services-21'),'existing free-service manager must remain packaged');
assert(h.includes("const shown='2.37'"),'visible version must be bumped for the release');
console.log('PASS free services management: visible workspace button invokes existing manager without changing its API');
